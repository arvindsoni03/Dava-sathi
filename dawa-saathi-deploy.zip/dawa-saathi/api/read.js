// Vercel serverless function: parchi (photo ya text) ko Claude se padhwata hai.
// API key sirf yahan server par rehti hai — kabhi browser mein nahi jaati.

const PROMPT = `You read Indian medical prescriptions (handwritten or printed, English/Hindi/Hinglish).
Extract every medicine. For each, give the generic salt name in English (e.g. "Telmisartan"), strength as a number string in mg if visible (e.g. "40"), the dose pattern as morning-afternoon-night like "1-0-1" (use "1-0-0" if only once daily and unclear), a short timing note in simple Hinglish (e.g. "Khane ke baad"), and confidence "high" | "medium" | "low" for how sure you are you read it correctly.
If the brand is known, infer the salt from it. Never invent medicines that aren't there. If the input is not a prescription, return [].
Respond with ONLY a JSON array, no other text: [{"brand":"","salt":"","strength":"","dose":"","note":"","confidence":""}]`;

// Bahut simple rate limit: ek IP se 1 minute mein 6 request (best effort)
const hits = new Map();
function limited(ip) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter(t => now - t < 60000);
  arr.push(now);
  hits.set(ip, arr);
  return arr.length > 6;
}

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "POST only" });

  const ip = (req.headers["x-forwarded-for"] || "").split(",")[0].trim() || "unknown";
  if (limited(ip)) return res.status(429).json({ error: "Too many requests" });

  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return res.status(500).json({ error: "ANTHROPIC_API_KEY set nahi hai" });

  const { image, text } = req.body || {};
  const content = [];

  if (image && typeof image.data === "string") {
    const okType = ["image/jpeg", "image/png", "image/webp"].includes(image.media_type);
    if (!okType) return res.status(400).json({ error: "Sirf JPG/PNG/WebP" });
    if (image.data.length > 4_000_000) return res.status(413).json({ error: "Photo bahut badi hai" });
    content.push({ type: "image", source: { type: "base64", media_type: image.media_type, data: image.data } });
    content.push({ type: "text", text: PROMPT + "\n\nThe attached image is the prescription." });
  } else if (typeof text === "string" && text.trim() && text.length < 5000) {
    content.push({ type: "text", text: PROMPT + "\n\nPrescription text:\n" + text });
  } else {
    return res.status(400).json({ error: "Photo ya text bhejein" });
  }

  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": key,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
      },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5",
        max_tokens: 1500,
        messages: [{ role: "user", content }],
      }),
    });

    if (!r.ok) {
      const detail = await r.text();
      console.error("Anthropic API error", r.status, detail.slice(0, 500));
      return res.status(502).json({ error: "AI se jawab nahi mila" });
    }

    const data = await r.json();
    const out = (data.content || []).map(b => (b.type === "text" ? b.text : "")).join("");
    const clean = out.replace(/```json|```/g, "").trim();
    const start = clean.indexOf("["), end = clean.lastIndexOf("]");
    let medicines = [];
    try { medicines = JSON.parse(clean.slice(start, end + 1)); } catch { medicines = []; }

    // Privacy: photo ya parchi kahin save nahi hoti — sirf jawab wapas jaata hai
    return res.status(200).json({ medicines: Array.isArray(medicines) ? medicines : [] });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: "Server error" });
  }
}
